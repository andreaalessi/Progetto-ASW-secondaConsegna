package facade;

import java.util.List;

import model.Gioco;
import persistence.exception.PersistenceException;

public interface GiocoFacade {
	
	public Gioco salvaGioco(Gioco gioco) throws PersistenceException;
	public List<Gioco> getAllGiochi() throws PersistenceException;
}
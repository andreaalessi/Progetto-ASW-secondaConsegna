package facade;

import java.util.ArrayList;
import java.util.List;

import model.Gioco;
import persistence.GiocoRepository;
import persistence.exception.PersistenceException;
import persistence.hibernate.GiocoDAO;

public class GiocoFacadeImpl implements GiocoFacade {
	
	public Gioco salvaGioco(Gioco gioco) throws PersistenceException {
		GiocoRepository giocoREP = new GiocoDAO();
		try {
			return giocoREP.save(gioco);
		} catch (PersistenceException pex) {
			pex.printStackTrace();
			return null;
		}
	}
	
	public List<Gioco> getAllGiochi() throws PersistenceException{
		List<Gioco> giocolist = new ArrayList<Gioco>();
		GiocoRepository giocoREP = new GiocoDAO();
			try{
				giocolist = giocoREP.doRetrieveAll();
			}
			catch(PersistenceException pex){pex.printStackTrace();}
		return giocolist;
	}

}



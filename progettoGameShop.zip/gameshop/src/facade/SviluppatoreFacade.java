package facade;

import java.util.List;

import model.Gioco;
import model.Sviluppatore;
import persistence.exception.PersistenceException;

public interface SviluppatoreFacade {
	
	public Sviluppatore salvaSviluppatore(Sviluppatore sviluppatore) throws PersistenceException;
	public Sviluppatore mostraSviluppatore(String nome) throws PersistenceException;
	public List<Sviluppatore> getAllSviluppatori() throws PersistenceException;
	//public Sviluppatore mostraSviluppatore(Long id) throws PersistenceException;
}
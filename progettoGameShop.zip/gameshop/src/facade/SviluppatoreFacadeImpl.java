package facade;

import java.util.ArrayList;
import java.util.List;

import model.Gioco;
import model.Sviluppatore;
import persistence.GiocoRepository;
import persistence.SviluppatoreRepository;
import persistence.exception.PersistenceException;
import persistence.hibernate.GiocoDAO;
import persistence.hibernate.SviluppatoreDAO;

public class SviluppatoreFacadeImpl implements SviluppatoreFacade {
	
	
	public Sviluppatore mostraSviluppatore(String nome) throws PersistenceException{
	   
		Sviluppatore sviluppatore=new Sviluppatore();
		SviluppatoreRepository sviluppatoreREP = new SviluppatoreDAO();
			try{
				sviluppatore = sviluppatoreREP.doRetrieveA(nome);
			}
			catch(PersistenceException pex){pex.printStackTrace();}
		return sviluppatore;
	}
	
	public List<Sviluppatore> getAllSviluppatori() throws PersistenceException{
		List<Sviluppatore> sviluppatorelist = new ArrayList<Sviluppatore>();
		SviluppatoreRepository sviluppatoreREP = new SviluppatoreDAO();
			try{
				sviluppatorelist = sviluppatoreREP.doRetrieveAll();
			}
			catch(PersistenceException pex){pex.printStackTrace();}
		return sviluppatorelist;
	}
	
/*	public Sviluppatore mostraSviluppatore(Long id) throws PersistenceException{
		Sviluppatore sviluppatore=new Sviluppatore();
		SviluppatoreRepository sviluppatoreREP = new SviluppatoreDAO();
			try{
				sviluppatore = sviluppatoreREP.doRetrieveA(id);
			}
			catch(PersistenceException pex){pex.printStackTrace();}
		return sviluppatore;
	}*/

	
	public Sviluppatore salvaSviluppatore(Sviluppatore sviluppatore) throws PersistenceException {
		SviluppatoreRepository sviluppatoreREP = new SviluppatoreDAO();
		try {
			return sviluppatoreREP.save(sviluppatore);
		} catch (PersistenceException pex) {
			pex.printStackTrace();
			return null;
		}
	}
}

package rest;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import facade.GiocoFacade;
import facade.GiocoFacadeImpl;
import facade.SviluppatoreFacade;
import facade.SviluppatoreFacadeImpl;
import model.Gioco;
import model.Sviluppatore;
import persistence.exception.PersistenceException;

@Path("/sviluppatore")
public class SviluppatoreService {

	@GET
	@Path("/lsSviluppatore")
	// @Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public List<Sviluppatore> lsSviluppatore() {
		SviluppatoreFacade fg = new SviluppatoreFacadeImpl();
		List<Sviluppatore> lsSviluppatore = new ArrayList<Sviluppatore>();
		try {
			lsSviluppatore = fg.getAllSviluppatori();
		} catch (PersistenceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return lsSviluppatore;
	}
}
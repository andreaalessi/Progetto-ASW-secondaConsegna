package rest;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import facade.GiocoFacade;
import facade.GiocoFacadeImpl;
import facade.SviluppatoreFacade;
import facade.SviluppatoreFacadeImpl;
import model.Gioco;
import model.Sviluppatore;
import persistence.exception.PersistenceException;

@Path("/gioco")
public class GiocoService {

	@GET
	@Path("/lsGioco")
	// @Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public List<Gioco> lsGioco() {
		GiocoFacade fg = new GiocoFacadeImpl();
		List<Gioco> lsGioco = new ArrayList<Gioco>();
		try {
			lsGioco = fg.getAllGiochi();
		} catch (PersistenceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return lsGioco;
	}

@POST
	@Path("/salvaGioco")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
	public Response salvaGioco(Gioco g){
		System.out.println(">>>>>>>>>SVILUPPATORE: " + g.getSviluppatore().getNome());
		GiocoFacade gf = new GiocoFacadeImpl();
		SviluppatoreFacade sf= new SviluppatoreFacadeImpl();
		try {
			String nomeSviluppatore=g.getSviluppatore().getNome();
			Sviluppatore sviluppatore= sf.mostraSviluppatore(nomeSviluppatore);
			if(sviluppatore == null){
				Sviluppatore s=new Sviluppatore(nomeSviluppatore);
				sf.salvaSviluppatore(s);
			}
			gf.salvaGioco(g);
		} catch (PersistenceException e) {
			e.printStackTrace();
		}
		System.out.println(g.toString());
		System.out.println(">>>>>>>>>>>>>>>>>Gioco Salvato");
		return Response.status(201).entity(g).build();

	}

}

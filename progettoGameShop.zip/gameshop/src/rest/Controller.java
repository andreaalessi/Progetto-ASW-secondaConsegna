package rest;

import javax.validation.constraints.NotNull;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.Consumes;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.view.Viewable;

import facade.GiocoFacade;
import facade.GiocoFacadeImpl;
import model.Gioco;
import model.Sviluppatore;
import persistence.exception.PersistenceException;

@Path("/")
public class Controller {

	private static final String BaseURI = "http://localhost:8080/gameshop/";

	Client client = Client.create();
	private final WebResource wr = client.resource(BaseURI);

	@GET
	public Viewable welcome() {
		return new Viewable("/index.jsp", "welcome");
	}

	@GET
	@Path("/home")
	public Viewable home() {
		return new Viewable("/index.jsp", "home");
	}

	@GET
	@Path("/aggiungiGioco")
	public Viewable aggiungiGioco() {
		return new Viewable("/aggiungiGioco.jsp", "aggiungiGioco");
	}

	@GET
	@Path("/catalogoGiochi")
	public Viewable catalogoGiochi() {
		return new Viewable("/catalogoGiochi.jsp", "catalogoGiochi");
	}
	
	@GET
	@Path("/catalogoSviluppatori")
	public Viewable catalogoSviluppatori() {
		return new Viewable("/catalogoSviluppatori.jsp", "catalogoSviluppatori");
	}

	@GET
	@Path("/saveGame")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Viewable doSave(@NotNull @QueryParam("nome") String nome,
			@NotNull @QueryParam("descrizione") String descrizione, @NotNull @QueryParam("prezzo") Float prezzo,@NotNull @QueryParam("sviluppatore") String sviluppatore)
	{
		if (nome.isEmpty() || descrizione.isEmpty()) {
			return null;
		}
		
		String input;
		System.out.println(">>>>>>>>>>>>>>>>>>>>>salva");
		input = "{\"nome\":\"" + nome + "\",\"descrizione\":\"" + descrizione + "\",\"prezzo\":\"" + prezzo + "\",\"sviluppatore\":\""+sviluppatore+"\"}";
		System.out.println(">>>>>>>>>>>>>>>>>>>>>salvaGioco=" + input);

		ClientResponse response = wr.path("/gioco").path("/salvaGioco").type(MediaType.APPLICATION_JSON)
				.post(ClientResponse.class, input);
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>client resp " + response.toString());

		JSONObject output = response.getEntity(JSONObject.class);
		return new Viewable("/index.jsp", output);
	}


	@GET
	@Path("/abc")
	// @Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Gioco nuovoGioco() {
		Sviluppatore s=new Sviluppatore("test");
		Gioco g = new Gioco("nome", "descrizione", (float) 21,s);
		return g;
	}

}
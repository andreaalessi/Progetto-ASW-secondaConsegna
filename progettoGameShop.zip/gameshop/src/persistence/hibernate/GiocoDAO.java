package persistence.hibernate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import facade.SviluppatoreFacade;
import facade.SviluppatoreFacadeImpl;
import model.Gioco;
import model.Sviluppatore;
import persistence.GiocoRepository;
import persistence.exception.PersistenceException;

public class GiocoDAO implements GiocoRepository{
	
	//salva un gioco nel db
		public Gioco save(Gioco gioco) throws PersistenceException{
			Session session = SingletonSessionFactory.getSessionFactory().openSession();
			Transaction transaction = null;
	        try {
	        	transaction=session.beginTransaction();
	            session.persist(gioco);
	            transaction.commit();
	        }
	        catch (Exception e){
	            if (transaction!=null) {transaction.rollback();}
	            throw new PersistenceException(e.getMessage());
	        }
	        finally {
	            session.close();
	        }
			return gioco;
		}
		
		public List<Gioco> doRetrieveAll() throws PersistenceException {
			List<Gioco> giocolist = new ArrayList<Gioco>();
			Session session = SingletonSessionFactory.getSessionFactory().openSession();
			Transaction transaction = null;
			try {
				transaction=session.beginTransaction();
				@SuppressWarnings("rawtypes")
				Iterator it =session.createSQLQuery("select * from gioco").list().iterator();
				while(it.hasNext()){
					Object[] tuple = (Object[]) it.next();
					
					Gioco g=new Gioco();
					g.setCodice((Long.parseLong(tuple[0].toString())));
					g.setDescrizione((String)tuple[1]);
					g.setNome((String)tuple[2]);
					g.setPrezzo((Float)tuple[3]);
					SviluppatoreFacade sf=new SviluppatoreFacadeImpl();
					String nome=((String)tuple[4]);
					Sviluppatore s=new Sviluppatore(nome);
					g.setSviluppatore(s);
					//g.setSviluppatore((Sviluppatore)sf.mostraSviluppatore((String)tuple[4]));
			/*		SviluppatoreFacade sf=new SviluppatoreFacadeImpl();
					//String nome=((String)tuple[4]);
					Long id=((Long.parseLong(tuple[4].toString())));
					g.setSviluppatore((Sviluppatore)sf.mostraSviluppatore(id));*/
				
					giocolist.add(g);
				}
				transaction.commit();
			}
			catch (Exception e){
				if (transaction!=null) {transaction.rollback();}
				throw new PersistenceException(e.getMessage());
			}
			finally {
				session.close();
			}
			return giocolist;
		}

}

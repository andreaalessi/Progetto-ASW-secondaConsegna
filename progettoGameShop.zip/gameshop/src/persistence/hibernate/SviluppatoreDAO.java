package persistence.hibernate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import facade.SviluppatoreFacade;
import facade.SviluppatoreFacadeImpl;
import model.Gioco;
import model.Sviluppatore;
import persistence.GiocoRepository;
import persistence.SviluppatoreRepository;
import persistence.exception.PersistenceException;

public class SviluppatoreDAO implements SviluppatoreRepository {

	// salva uno Sviluppatore nel db
	public Sviluppatore save(Sviluppatore sviluppatore) throws PersistenceException {
		Session session = SingletonSessionFactory.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			session.persist(sviluppatore);
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			throw new PersistenceException(e.getMessage());
		} finally {
			session.close();
		}
		return sviluppatore;
	}

	/*
	 * public Sviluppatore doRetrieveA(String nome) throws PersistenceException
	 * { Session session =
	 * SingletonSessionFactory.getSessionFactory().openSession(); Transaction tx
	 * = null; Sviluppatore s=null; try{ tx = session.beginTransaction(); s =
	 * (Sviluppatore)session.get(Sviluppatore.class, nome); }catch
	 * (HibernateException e) { if (tx!=null) tx.rollback();
	 * e.printStackTrace(); }finally { session.close(); } return s; }
	 */

	/*
	 * public Sviluppatore doRetrieveA(String nome) throws PersistenceException
	 * { Sviluppatore s = null;
	 * 
	 * Session session =
	 * SingletonSessionFactory.getSessionFactory().openSession(); Transaction
	 * transaction = null; try { transaction = session.beginTransaction(); s =
	 * (Sviluppatore) session.get(Sviluppatore.class, nome);
	 * transaction.commit(); } catch (Exception e) { if (transaction != null) {
	 * transaction.rollback(); } throw new PersistenceException(e.getMessage());
	 * } finally { session.close(); } return s; }
	 */

	public Sviluppatore doRetrieveA(String nome) throws PersistenceException {
		Session session = SingletonSessionFactory.getSessionFactory().openSession();
		Transaction transaction = null;
		Sviluppatore s = null;
		try {
			s = (Sviluppatore) session.get(Sviluppatore.class, new String(nome));
			System.out.println(">>>>>>sviluppatore: " + s.toString());

			transaction.commit();
		} catch (Exception e) {

		} finally {
			session.close();
		}

		return s;
	}
	
	public List<Sviluppatore> doRetrieveAll() throws PersistenceException {
		List<Sviluppatore> sviluppatorelist = new ArrayList<Sviluppatore>();
		Session session = SingletonSessionFactory.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction=session.beginTransaction();
			@SuppressWarnings("rawtypes")
			Iterator it =session.createSQLQuery("select * from sviluppatore").list().iterator();
			while(it.hasNext()){
				Object[] tuple = (Object[]) it.next();
				
				Sviluppatore g=new Sviluppatore();
				g.setNome((String)tuple[0]);
			
				sviluppatorelist.add(g);
			}
			transaction.commit();
		}
		catch (Exception e){
			if (transaction!=null) {transaction.rollback();}
			throw new PersistenceException(e.getMessage());
		}
		finally {
			session.close();
		}
		return sviluppatorelist;
	}

	/*
	 * public Sviluppatore doRetrieveA(Long id) throws PersistenceException {
	 * Session session =
	 * SingletonSessionFactory.getSessionFactory().openSession(); Transaction
	 * transaction = null; Sviluppatore s=null; try {
	 * transaction=session.beginTransaction();
	 * 
	 * @SuppressWarnings("rawtypes") Iterator it =session.createSQLQuery(
	 * "select * from sviluppatore where codice='"+id+"'").list().iterator();
	 * if(it.hasNext()){ s=new Sviluppatore(); Object[] tuple = (Object[])
	 * it.next();
	 * 
	 * s.setCodice((Long.parseLong(tuple[0].toString())));
	 * s.setNome((String)tuple[1]); } transaction.commit(); } catch (Exception
	 * e){ if (transaction!=null) {transaction.rollback();} throw new
	 * PersistenceException(e.getMessage()); } finally { session.close(); }
	 * 
	 * return s; }
	 */

}
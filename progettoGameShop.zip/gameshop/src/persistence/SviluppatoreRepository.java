package persistence;

import java.util.List;

import model.Gioco;
import model.Sviluppatore;
import persistence.exception.PersistenceException;

public interface SviluppatoreRepository {
	
	Sviluppatore save(Sviluppatore sviluppatore) throws PersistenceException;
	Sviluppatore doRetrieveA(String nome) throws PersistenceException;
	List<Sviluppatore> doRetrieveAll() throws PersistenceException;
	//Sviluppatore doRetrieveA(Long id) throws PersistenceException;

}

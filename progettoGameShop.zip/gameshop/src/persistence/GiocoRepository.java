package persistence;

import java.util.List;

import model.Gioco;
import persistence.exception.PersistenceException;

public interface GiocoRepository {
	
	Gioco save(Gioco gioco) throws PersistenceException;
	List<Gioco> doRetrieveAll() throws PersistenceException;

}

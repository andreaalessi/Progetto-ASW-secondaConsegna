package model;
import javax.persistence.*;


@Entity
@Table(name="gioco") 
public class Gioco {

	@Id
	@GeneratedValue (strategy = GenerationType.AUTO)
	private Long codice;
	
	@Column(nullable=false)
	private String nome;
	
	@Column(length=1000)
	private String descrizione;
	
	@Column(nullable=false)
	private Float prezzo;
	
	@ManyToOne
	//@ManyToOne  (cascade=CascadeType.ALL)
	private Sviluppatore sviluppatore;

	
	public Gioco(){
		super();
	}
	
	public Gioco(String nome, String descrizione, Float prezzo,Sviluppatore sviluppatore) {
		this.nome = nome;
		this.descrizione = descrizione;
		this.prezzo = prezzo;
		this.sviluppatore = sviluppatore;
	}

	public Long getCodice() {
		return codice;
	}

	public void setCodice(Long codice) {
		this.codice = codice;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public Float getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(Float prezzo) {
		this.prezzo = prezzo;
	}

	public Sviluppatore getSviluppatore() {
		return sviluppatore;
	}

	public void setSviluppatore(Sviluppatore sviluppatore) {
		this.sviluppatore = sviluppatore;
	}
	
	public String toString(){
		return "nome: " + getNome() + "descrizione: " + getDescrizione() + "prezzo: "+getPrezzo();
	}
	
	
	
}

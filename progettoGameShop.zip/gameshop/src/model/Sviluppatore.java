package model;
import java.util.List;

import javax.persistence.*;


@Entity
@Table(name="sviluppatore") 
public class Sviluppatore {

/*	@Id
	@GeneratedValue (strategy = GenerationType.AUTO)
	private Long codice;*/
	
	@Id
	@Column(nullable=false,unique=true)
	private String nome;
	
	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	@Column
	private String descrizione;
	
	@OneToMany(mappedBy = "sviluppatore")
	private List<Gioco> giochi;


	public Sviluppatore(){
		super();
	}
	
	public Sviluppatore(String nome) {
		this.nome = nome;
	}

/*	public Long getCodice() {
		return codice;
	}

	public void setCodice(Long codice) {
		this.codice = codice;
	}*/

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}


	public List<Gioco> getGiochi() {
		return giochi;
	}

	public void setGiochi(List<Gioco> giochi) {
		this.giochi = giochi;
	}

	@Override
	public String toString() {
		return "Sviluppatore [nome=" + nome + ", giochi=" + giochi + "]";
	}



	
	
	
	
}